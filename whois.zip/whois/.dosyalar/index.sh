#!/data/data/com.termux/files/bash

#genel ayarlar
clear
figlet -f small CyberTeam |lolcat
echo -e "\e[32m

Yapımcı : CyberOfficial                     
Grup : CyberTeam                            
Rütbe : Kurucu Yardımcısı [ KY ]            
Instagram : @cyber.offical                  
Instagram Grup : @cyberteamofficial
                                            
\e[0m"

echo
echo
echo
echo
echo -e "\e[32m [1] Whois Çek\e[0m"
echo -e "\e[32m [2] IP Bilgi Çek\e[0m"
echo -e "\e[32m [3] Çıkış\e[0m"
read -p "Root@CyberTeam > " sayi;

if [ $sayi = 1 ]
then
clear
echo -e "\e[32m

Yapımcı : CyberOfficial
Grup : CyberTeam
Rütbe : Kurucu Yardımcısı [ KY ]
Instagram : @cyber.offical
Instagram Grup : @cyberteamofficial

\e[0m"

echo
echo
echo -e "\e[31m Kullanımı :

IP İle Çekeçekseniz : 127.0.0.1 

Domain İle Çekecekseniz : domain.com\e[0m"
echo
echo
echo


read -p "Domain Veya  IP Adres > " whois;
          					        	     	 							    
command=$(wget http://api.hackertarget.com/whois/?q=$whois -q -O .-)
echo
echo                 
cat .-
echo
echo
fi			

if [ $sayi = 2 ]
then
clear
echo -e "\e[32m

Yapımcı : CyberOfficial
Grup : CyberTeam
Rütbe : Kurucu Yardımcısı [ KY ]
Instagram : @cyber.offical
Instagram Grup : @cyberteamofficial

\e[0m"
echo
echo
echo -e  "\e[31m Kullanımı : 

IP Adres İle Çekme : 127.0.0.1 Veya http://127.0.0.1/

URL İle Çekme : domain.com,http://domain.com/,http://www.domain.com/
\e[0m"

echo
echo
echo
 

read -p "Domain Veya IP Adres > " ipwhois;

command=$(wget http://api.hackertarget.com/geoip/?q=$ipwhois -q -O .-);
echo 
echo

cat .-
echo
echo
sleep 1

fi

if [ $sayi = 3 ]
then
clear
figlet -f small CyberTeam |lolcat
echo -e "\e[31m Görüşmek Üzere Dostum Tekrar Bekleriz!\e[0m"
exit
echo
echo
echo

fi
