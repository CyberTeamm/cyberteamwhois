#!/data/data/com.termux/files/bin/bash


#genel ayarlar
clear

figlet -f small CyberTeam|lolcat

echo -e "\e[32m

Yapımcı : CyberOfficial

Grup : CyberTeam

Rütbe : Kurucu Yardımcısı [ KY ]

Instagram : @cyber.offical 

Instagram Grup : @cyberteamofficial



\e[0m"

figlet -f small  A c i l i y o r...|lolcat

sleep 2

bash .dosyalar/index.sh
